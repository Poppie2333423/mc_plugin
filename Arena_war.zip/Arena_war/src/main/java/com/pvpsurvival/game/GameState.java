package com.pvpsurvival.game;

public enum GameState {
    WAITING,
    STARTING,
    PREPARATION,
    PVP_ENABLED
}